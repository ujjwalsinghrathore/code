// Contact Form Scripts

$(function() {

    $("#contactForm input,#contactForm textarea").jqBootstrapValidation({
       
        submitError: function($form, event, errors) {
            // additional error messages or events
        },
        
        
    });

    
});


